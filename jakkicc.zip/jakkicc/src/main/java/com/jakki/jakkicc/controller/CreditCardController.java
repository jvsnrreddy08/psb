package com.jakki.jakkicc.controller;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jakki.jakkicc.service.CreditCardService;

/**
 * This is the main method where the application is triggered.
 * 
 * @author Sainath
 *
 */
public class CreditCardController {

	public static void main(String[] args) {

		final Logger logger = Logger.getLogger(CreditCardController.class);

		logger.info("main method has been invoked");

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-servlet.xml");

		CreditCardService creditCardService = (CreditCardService) context.getBean("service");
		creditCardService.processApplication();

	}
}
