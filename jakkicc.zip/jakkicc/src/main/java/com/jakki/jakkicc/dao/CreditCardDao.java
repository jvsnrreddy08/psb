package com.jakki.jakkicc.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.engine.spi.SessionFactoryImplementor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.jakki.jakkicc.model.Applicant;
import com.jakki.jakkicc.model.CreditCard;

@Repository
@Transactional
public class CreditCardDao {

	@Autowired
	private SessionFactory sessionFactory;

	final Logger logger = Logger.getLogger(CreditCardDao.class);

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/**
	 * This method is used to get the list of applicants whose appliation status
	 * is new.
	 * 
	 * @return
	 */
	public List<Applicant> getApplicationsList() {

		Session session = this.sessionFactory.openSession();
		Query query = session.createQuery("FROM Applicant WHERE applicationStatus=:username");

		query.setString("username", "New");

		List<Applicant> returnedMembers = query.list();

		session.close();
		logger.info("the list of applicants whose application status is new has been obtained");

		return returnedMembers;

	}

	/**
	 * this method is used to update the applicant record with the application
	 * status as approved or rejected.
	 * 
	 * @param applicant
	 */
	public void updateApplicant(Applicant applicant) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-servlet.xml");

		SessionFactoryImplementor sessionFactory = (SessionFactoryImplementor) context
				.getBean("hibernate4AnnotatedSessionFactory");

		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();

		session.update(applicant);
		t.commit();

		logger.info("applicant detials have been updated");

	}

	/**
	 * This method is used to save the credit card details in the database.
	 * 
	 * @param creditCard
	 */
	public void saveCreditCard(CreditCard creditCard) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-servlet.xml");

		SessionFactoryImplementor sessionFactory = (SessionFactoryImplementor) context
				.getBean("hibernate4AnnotatedSessionFactory");

		Session session = sessionFactory.openSession();
		Transaction t = session.beginTransaction();

		session.persist(creditCard);
		logger.info("creditcard detials have been saved into database");
		t.commit();

		session.close();

	}

}
