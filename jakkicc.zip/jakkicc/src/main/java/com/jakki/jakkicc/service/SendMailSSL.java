package com.jakki.jakkicc.service;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * This method is used to send email to the customer.
 * 
 * @author Sainath
 *
 */
public class SendMailSSL {

	public void sendMail(String mailid, String subject, String message) {

		Mailer.send(" jakkiccc@gmail.com", "jakkiikkaj", mailid, subject, message);

	}
}

/**
 * This class is used for sending emails to the creditcard applicants about the
 * status of the application.
 */
class Mailer {

	/**
	 * This method contains the detials about the mail server and sender email
	 * and password.
	 */
	public static void send(String from, String password, String to, String sub, String msg) {

		// Get properties object
		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");
		// get Session
		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("jakkiccc@gmail.com", "jakkiikkaj");
			}
		});
		// compose message
		try {
			MimeMessage message = new MimeMessage(session);
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
			message.setSubject(sub);
			message.setText(msg);
			// send message
			Transport.send(message);
			System.out.println("message sent successfully");
		} catch (MessagingException e) {

			throw new RuntimeException(e);
		}

	}
}