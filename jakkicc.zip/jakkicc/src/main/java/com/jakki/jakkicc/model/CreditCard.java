package com.jakki.jakkicc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This is an entity class which holds creditCard data
 * 
 * @author Sainath
 */
@Entity
@Table(name = "creditcard")
public class CreditCard {

	@Id
	@GeneratedValue
	private int creditcardid;
	private String creditCardNumber;
	private String nameOnTheCard;
	private String cvv;
	private String expiryDate;

	private String creditLimit;

	private String cardStatus = "not-activated";

	private int applicantId;

	public int getApplicantId() {
		return applicantId;
	}

	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}

	public int getCreditcardid() {
		return creditcardid;
	}

	public void setCreditcardid(int creditcardid) {
		this.creditcardid = creditcardid;
	}

	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getNameOnTheCard() {
		return nameOnTheCard;
	}

	public void setNameOnTheCard(String nameOnTheCard) {
		this.nameOnTheCard = nameOnTheCard;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}

	@Override
	public String toString() {
		return "CreditCard [creditcardid=" + creditcardid + ", creditCardNumber=" + creditCardNumber
				+ ", nameOnTheCard=" + nameOnTheCard + ", cvv=" + cvv + ", expiryDate=" + expiryDate + ", creditLimit="
				+ creditLimit + ", applicantId=" + applicantId + "]";
	}

}
