package com.jakki.jakkicc.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * @author Sainath
 * This is an entity class which holds Applicant data 
 */
@Entity
@Table(name = "applicant")
public class Applicant {

	
	@Id
	@GeneratedValue
	int id;

	private String firstName;
	private String middleName;
	private String lastName;
	private String phoneNumber;

	private String email;
	private String dateOfBirth;

	private String ssn;
	private String annualIncome;
	private String monthlyHouseRent;

	private String applicationStatus;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Address_Id")

	private Address address;

	public int getId() {
		return id;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSsn() {
		return ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getAnnualIncome() {
		return annualIncome;
	}

	public void setAnnualIncome(String annualIncome) {
		this.annualIncome = annualIncome;
	}

	public String getMonthlyHouseRent() {
		return monthlyHouseRent;
	}

	public void setMonthlyHouseRent(String monthlyHouseRent) {
		this.monthlyHouseRent = monthlyHouseRent;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@PrimaryKeyJoinColumn
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	@Override
	public String toString() {
		return "Applicant [id=" + id + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", phoneNumber=" + phoneNumber + ", email=" + email + ", dateOfBirth=" + dateOfBirth
				+ ", ssn=" + ssn + ", annualIncome=" + annualIncome + ", monthlyHouseRent=" + monthlyHouseRent
				+ ", applicationStatus=" + applicationStatus + ", address=" + address + "]";
	}

}
