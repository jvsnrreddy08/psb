package com.jakki.jakkicc.service;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.jakki.jakkicc.dao.CreditCardDao;
import com.jakki.jakkicc.model.Applicant;

/**
 * This class implements the runnable interface.
 * 
 * @author Sainath
 */
class EquifaxService implements Runnable {

	CreditCardDao creditCardDao;
	Applicant applicant;

	final Logger logger = Logger.getLogger(EquifaxService.class);

	public EquifaxService(Applicant applicant) {
		this.applicant = applicant;
	}

	public CreditCardDao getCreditCardDao() {
		return creditCardDao;
	}

	public void setCreditCardDao(CreditCardDao creditCardDao) {
		this.creditCardDao = creditCardDao;
	}

	/**
	 * This method contains the actual logic. This method is executed by
	 * threads.
	 */
	public void run() {

		System.out.println(Thread.currentThread().getName() + " (Start)  ");

		try {

			new CreditCardService().verifyApplicant(applicant);
			logger.info("the logic in run method has been invoked");

		} catch (IOException e) {
			logger.error(e);
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName() + " (End)");// prints
																		// thread
																		// name

	}

}
