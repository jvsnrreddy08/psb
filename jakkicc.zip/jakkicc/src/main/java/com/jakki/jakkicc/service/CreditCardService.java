package com.jakki.jakkicc.service;

import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import com.jakki.jakkicc.dao.CreditCardDao;

import com.jakki.jakkicc.model.Applicant;
import com.jakki.jakkicc.model.CreditCard;

/**
 * This class contains method that are going to perform appropriate operation .
 * 
 * @author Sainath
 *
 */
public class CreditCardService {

	CreditCardDao creditCardDao;

	final Logger logger = Logger.getLogger(CreditCardService.class);

	public void setcreditCardDao(CreditCardDao creditCardDao) {
		this.creditCardDao = creditCardDao;
	}

	/**
	 * This method is used to get all the applicants whose application status is
	 * new and process them accordingly.
	 */
	public void processApplication() {

		List<Applicant> applicants = creditCardDao.getApplicationsList();
		ExecutorService executor = Executors.newFixedThreadPool(5);

		Iterator itr = applicants.iterator();

		while (itr.hasNext()) {
			Runnable worker = new EquifaxService((Applicant) itr.next());
			logger.info("A task has been assigned to a thread in thread pool");
			executor.execute(worker);
		}

		Boolean allTasksDone = true;

		executor.shutdown();
		while (!executor.isTerminated()) {
		}

	}

	/**
	 * This method is used to process the applicant information and sets the
	 * status as approved or rejected.
	 * 
	 * @param applicant
	 * @throws IOException
	 */
	public void verifyApplicant(Applicant applicant) throws IOException {

		SendMailSSL smsll = new SendMailSSL();
		CreditCard creditCard = new CreditCard();

		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("equifax.txt");

		BufferedReader r = new BufferedReader(new InputStreamReader(inputStream));

		String line;
		while ((line = r.readLine()) != null) {
			String feilds[] = line.split(" ");

			logger.info("a line has been read from the equifax.txt file" + line);

			if (applicant.getSsn().equals(feilds[2])) {

				if (Integer.parseInt(feilds[3]) > 700) {

					applicant.setApplicationStatus("Approved");
					creditCard.setCreditLimit("10000");

					String amount = generateCreditCard(applicant, creditCard);

					String subject = "Approved";

					String message = "Hello" + " ," + applicant.getFirstName() + " " + applicant.getLastName() + " "
							+ "Thank you for applying credit card with us. We processed your request and we approved it."
							+ " " + "Your card number is" + creditCard.getCreditCardNumber() + ", "
							+ "Your card limit is" + creditCard.getCreditLimit();

					smsll.sendMail(applicant.getEmail(), subject, message);

				} else {
					applicant.setApplicationStatus("Rejected");

					String subject = "jakkicreditcard";
					String message = "Thank you for applying credit card with us. We are unable to process your request. Please feel free to contact us regarding your application.";

					smsll.sendMail(applicant.getEmail(), subject, message);

				}

				new CreditCardDao().updateApplicant(applicant);
			}
		}

	}

	/**
	 * This method is used to generate the credit card. Once the status of the
	 * application is set to approved.
	 * 
	 * @param applicant
	 * @return
	 */
	public String generateCreditCard(Applicant applicant, CreditCard creditCard) {

		Random rnd = new Random();
		Calendar now = Calendar.getInstance();
		String year = String.valueOf(now.get(Calendar.YEAR) + 5);
		String month = String.valueOf(now.get(Calendar.MONTH) + 1);

		int creditCard1 = 100000000 + rnd.nextInt(900000000);
		int creditCard2 = 100000 + rnd.nextInt(900000);
		int cvv = 1000 + rnd.nextInt(9000);

		creditCard.setCreditCardNumber(String.valueOf(creditCard1) + String.valueOf(creditCard2));
		creditCard.setNameOnTheCard(applicant.getFirstName());
		creditCard.setCvv(String.valueOf(cvv));
		creditCard.setExpiryDate("month/" + year.substring(2));

		creditCard.setApplicantId(applicant.getId());

		new CreditCardDao().saveCreditCard(creditCard);

		return creditCard.getCreditCardNumber() + "," + creditCard.getCreditLimit();

	}
}
